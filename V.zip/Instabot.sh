#!/bin/bash
#version 3.0
#HAK CIPTA MILIK INFECTED_AOFSFOF

clear
python2 Security.py
python Restart.py
clear
git clone https://github.com/Infected14741/modules
clear
cd modules
mv node_modules.zip /$HOME/Instabot-Infected-aofsfof
cd
cd Instabot-Infected-aofsfof
unzip node_modules.zip
clear
rm -rf node_modules.zip
git clone https://github.com/Infected14741/index
clear
cd index
mv index.js /$HOME/Instabot-Infected-aofsfof
cd
cd Instabot-Infected-aofsfof
rm -rf index
git clone https://github.com/Infected14741/run
clear
cd run
unzip run.zip
cd run
mv run.sh /$HOME/Instabot-Infected-aofsfof
cd
cd Instabot-Infected-aofsfof
rm -rf run
sh run.sh
rm -rf run.sh
rm -rf index.js
